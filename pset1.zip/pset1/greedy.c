#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
   int coin_values[8] = {1000, 500, 100, 50, 25, 10, 5, 1};

   float amount = get_float("O hai! How much change is owed?\n");

   while (amount<0)
    {
     amount = get_float("How much change is owed?\n");
    }

   int cents = round(100*amount);

   int number_of_coins = 0;

   for (int i = 0; i < 9; i++)
    {
     number_of_coins = number_of_coins + trunc(cents/coin_values[i]);
     cents = cents % coin_values[i];
    }

   printf("Number of coins: %i\n", number_of_coins);

}