#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int m = get_int("How much minutes did you take a shower? ");
    int b = m * 12;
    printf("minutes: %i\nbottles: %i \n", m, b);
}